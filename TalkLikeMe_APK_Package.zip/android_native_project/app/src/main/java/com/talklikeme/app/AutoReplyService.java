package com.talklikeme.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.Locale;

public class AutoReplyService extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        // Listen to Facebook Messenger (com.facebook.orca), Messenger Lite, and WhatsApp (com.whatsapp)
        if (!"com.facebook.orca".equals(pkg) && !"com.facebook.mlite".equals(pkg) && !"com.whatsapp".equals(pkg)) {
            return;
        }

        Notification notification = sbn.getNotification();
        if (notification == null || notification.extras == null) return;

        // Avoid replying to our own outgoing messages or group summaries
        if ((notification.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;

        CharSequence rawText = notification.extras.getCharSequence(Notification.EXTRA_TEXT);
        if (rawText == null) return;

        String incoming = rawText.toString().trim();
        if (incoming.isEmpty()) return;

        // Find Quick Reply action attached to the Messenger/WhatsApp notification
        Notification.Action replyAction = findReplyAction(notification);
        if (replyAction == null) return;

        // Generate human-like reply matching language (Tanglish vs English)
        String replyText = generateSmartReply(incoming);
        if (replyText != null) {
            sendAutomaticReply(replyAction, replyText);
        }
    }

    private Notification.Action findReplyAction(Notification notification) {
        if (notification.actions == null) return null;
        for (Notification.Action action : notification.actions) {
            if (action.getRemoteInputs() != null && action.getRemoteInputs().length > 0) {
                return action;
            }
        }
        return null;
    }

    private boolean isTanglish(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        String[] tokens = {
            "panringa", "panra", "saptingala", "saptya", "saapten", "irukinga",
            "irukka", "polama", "veliya", "enna", "epdi", "romba", "kandippa",
            "summa", "seri", "machan", "thala", "nalaikku", "unga", "neenga"
        };
        for (String t : tokens) {
            if (lower.contains(t)) return true;
        }
        return false;
    }

    private String generateSmartReply(String incoming) {
        String lower = incoming.toLowerCase(Locale.ROOT);
        boolean tanglish = isTanglish(lower);

        if (tanglish) {
            if (lower.contains("panringa") || lower.contains("panra")) {
                return "unga text-ku wait panitu irundhen 😉 neenga enna panringa ippo?";
            }
            if (lower.contains("saptingala") || lower.contains("saptya")) {
                return "ippo dhan saapten pa! neenga saaptingala? ☕";
            }
            if (lower.contains("polama") || lower.contains("coffee") || lower.contains("meet") || lower.contains("free")) {
                return "kandippa polama! when are you free this week?";
            }
            if (lower.contains("epdi irukinga") || lower.contains("epdi irukka")) {
                return "romba nalla irukken pa! day epdi pochu ungalukku?";
            }
            return null; // Only auto-reply to known conversational openers to stay natural
        } else {
            if (lower.contains("what are you doing") || lower.contains("what's up") || lower.contains("up to")) {
                return "was just relaxing, but could definitely make room for you 😉 what are you up to?";
            }
            if (lower.contains("did you eat") || lower.contains("dinner") || lower.contains("lunch")) {
                return "just ate, thanks for asking! did you eat yet?";
            }
            if (lower.contains("coffee") || lower.contains("free") || lower.contains("hang")) {
                return "coffee sounds good, but only if you pick a solid spot 😉 when were you thinking?";
            }
            if (lower.contains("how are you") || lower.contains("how's it going")) {
                return "doing well! how has your day been treating you?";
            }
            return null;
        }
    }

    private void sendAutomaticReply(Notification.Action action, String replyMessage) {
        try {
            Intent intent = new Intent();
            Bundle bundle = new Bundle();
            for (RemoteInput remoteInput : action.getRemoteInputs()) {
                bundle.putCharSequence(remoteInput.getResultKey(), replyMessage);
            }
            RemoteInput.addResultsToIntent(action.getRemoteInputs(), intent, bundle);
            action.actionIntent.send(this, 0, intent);
        } catch (PendingIntent.CanceledException e) {
            e.printStackTrace();
        }
    }
}
